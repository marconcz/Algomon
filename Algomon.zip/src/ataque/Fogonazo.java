package ataque;

public class Fogonazo extends AtaqueDeFuego {
	
	public Fogonazo(){
		this.potencia = 2;
		this.cantidad = 4;
	}

}
