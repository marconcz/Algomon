package ataque;

public class Chupavidas extends AtaqueDeHierba {
	
	public Chupavidas(){
		this.potencia = 15;
		this.cantidad = 8;
	}
}
