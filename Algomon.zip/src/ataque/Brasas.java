package ataque;

public class Brasas extends AtaqueDeFuego {
	
	public Brasas(){
		this.potencia = 16;
		this.cantidad = 10;
	}

}
