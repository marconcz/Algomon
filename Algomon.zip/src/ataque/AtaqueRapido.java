package ataque;


import ataque.AtaqueNormal;

public class AtaqueRapido extends AtaqueNormal{
	
	public AtaqueRapido(){
		this.potencia = 10;
		this.cantidad = 16;
	}

}
