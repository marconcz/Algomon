package ataque;

public class CañonDeAgua extends AtaqueDeAgua {

	public CañonDeAgua(){
		this.potencia = 20;
		this.cantidad = 8;
	}
}

