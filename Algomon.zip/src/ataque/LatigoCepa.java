package ataque;

public class LatigoCepa extends AtaqueDeHierba{

	public LatigoCepa(){
		this.potencia = 15;
		this.cantidad = 10;
	}
}
