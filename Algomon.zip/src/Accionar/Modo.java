package Accionar;

import ataque.Ataque;
import pokemon.Pokemon;

public class Modo implements Accionable{

	public Modo siguienteModo() {
		// TODO Auto-generated method stub
		return null;
	}

	public void accionar(Ataque unAtaque, Pokemon objetivo) {
		// TODO Auto-generated method stub
		
	}

}
