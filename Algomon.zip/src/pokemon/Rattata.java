package pokemon;

public class Rattata extends NormalTypePokemon{

	protected double HPMax = 170;
	
	public Rattata(){
		super();
	}
}
