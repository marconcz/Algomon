package pokemon;

public class Chansey extends NormalTypePokemon{
	
	protected double HPMax = 130;
	
	public Chansey(){
		super();
	}

}
