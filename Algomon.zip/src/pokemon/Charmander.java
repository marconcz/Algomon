package pokemon;

public class Charmander extends FireTypePokemon{

	protected double HPMax = 170;
	
	public Charmander(){
		super();
	}

	






}



