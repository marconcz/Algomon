package pokemon;

public class Squirtle extends WaterTypePokemon {

	protected double HPMax = 150;
	
	public Squirtle(){
		super();
	}
}
