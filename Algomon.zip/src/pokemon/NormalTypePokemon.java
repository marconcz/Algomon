package pokemon;

public abstract class NormalTypePokemon extends Pokemon{

	// Un pkmn de tipo normal inflinge da�o normal a todos los tipos y sufre da�o normal ante cualquier tipo
	// Se comporta exactamente igual que los metodos de la clase de la que hereda, asi que aca no habria nada que implementar por ahora
}
