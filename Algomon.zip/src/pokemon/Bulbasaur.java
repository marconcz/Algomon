package pokemon;

public class Bulbasaur extends GrassTypePokemon{
	
	protected double HPMax = 140;
	
	public Bulbasaur(){
		super();
	}

}
