package pokemon;

public class Jigglypuff extends NormalTypePokemon {

	protected double HPMax = 130;
	
	public Jigglypuff(){
		super();
	}
}
